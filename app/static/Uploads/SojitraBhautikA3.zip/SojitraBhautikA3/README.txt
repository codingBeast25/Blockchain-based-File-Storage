

Name : Bhautik Sojitra
Student Id: 7900140
Course: Introduction to Cryptography and CryptoSystems (COMP 4140)
Assignment #3
Purpose: Build an AES encryption and decryption scheme 

User Instructions:

How to Compile & Run the program:

To Compile: make 

To Run: ./AES test1plaintext.txt test1key.txt [Here, the first argument is the filename containing plaintext as hex values 
                                               & second argument is filename containing key as hex values ] 
                                
To CleanUp the executables : make clean